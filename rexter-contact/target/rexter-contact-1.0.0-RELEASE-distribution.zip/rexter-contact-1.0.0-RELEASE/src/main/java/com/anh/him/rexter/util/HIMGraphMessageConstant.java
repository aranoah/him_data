package com.anh.him.rexter.util;

public class HIMGraphMessageConstant {

	public static String CIRCLE_NOT_EXIST = "circle does not exists";
	public static String UNKNOWN_ERROR = "Server could not perform the request.";
	public static String EDGE_EXISTS = "An edge with the given type already exists.";
	public static String MISSING_SERVICE = "Service Id is missing";

}
